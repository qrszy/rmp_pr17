﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract9._2
{
    public class Test
    {
        public bool getm(string x)
        {
            bool X = true;
            if (x == "") return X = false;
            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= 2000 && A > 1) X = true;
            else X = false;
            return X;
        }
        public bool getk(string x, int m)
        {
            bool X = true;
            if (x == "") return X = false;
            X = true;

            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= m && A > 0) X = true;
            else X = false;
            return X;
        }
        public bool check1s(double x)
        {
            bool X = true;
             int kol = 0;
            string str = x.ToString();
            for (int i = 2; i < str.Length - 1; i++)
            {
                if (str[i] == str[i + 1]) kol++;
            }
            if (kol == str.Length - 3 || kol == str.Length - 5 || kol == str.Length - 2 || kol == str.Length - 4) X = true;
            else X = false;
            return X;
        }
        public bool check2s(double x)
        {
            bool X = true;
            int kol = 0;
            int index = 0;
            string str = x.ToString();
            if (str[2].ToString() != str[3].ToString())
            {
                string dvas = str[2].ToString() + str[3].ToString();
                for (int i = 4; i < str.Length - 1; i++)
                {
                    if (dvas == str[i].ToString() + str[i + 1].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }
        public bool check3s(double x)
        {
            bool X = true;
            int kol = 0;
            int index = 0;
            string str = x.ToString();
            if (str[2].ToString() != str[3].ToString() && str[3].ToString() != str[4].ToString() && str[2].ToString() + str[3].ToString() != str[4].ToString() + str[5].ToString())
            {
                string trs = str[2].ToString() + str[3].ToString() + str[4].ToString();
                for (int i = 5; i < str.Length - 2; i++)
                {
                    if (trs == str[i].ToString() + str[i + 1].ToString() + str[i + 2].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }
        public bool check4s(double x)
        {
            bool X = true;
            int kol = 0;
            int index = 0;
            string str = x.ToString();
            if (str[2].ToString() + str[3].ToString() != str[4].ToString() + str[5].ToString())
            {
                string fous = str[2].ToString() + str[3].ToString() + str[4].ToString() + str[5].ToString();
                for (int i = 6; i < str.Length - 3; i++)
                {
                    if (fous == str[i].ToString() + str[i + 1].ToString() + str[i + 2].ToString() + str[i + 3].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }
    }
}
