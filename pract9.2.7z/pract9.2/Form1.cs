﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract9._2
{
    public partial class Form1 : Form
    {
        public bool getm(string x,out bool X)
        {
            if (x == "") return X = false;
            X = true;
            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= 2000 && A > 1) X = true;
            else X = false;
            return X;
        }
        public bool getk(string x,int m,out bool X)
        {
            if (x == "") return X = false;
             X = true;

            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= m && A > 0) X = true;
            else X = false;
            return X;
        }
        public bool check1s(double x,out bool X, out int kol) 
        {
            kol = 0;
           string str=x.ToString();
            for (int i = 2;i < str.Length-1; i++) 
            {
                if (str[i] == str[i + 1])kol++;
            }
            if (kol == str.Length - 3 || kol == str.Length - 5|| kol == str.Length - 2 || kol == str.Length - 4) X = true;
            else X=false;
            return X;
        }
        public bool check2s(double x, out bool X, out int kol,out int index)
        {
            kol = 0;
            index = 0;
            string str = x.ToString();
            if (str[2].ToString() != str[3].ToString())
            {
                string dvas = str[2].ToString() + str[3].ToString();
                for (int i = 4; i < str.Length - 1; i++)
                {
                    if (dvas == str[i].ToString() + str[i + 1].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }
        public bool check3s(double x, out bool X, out int kol, out int index)
        {
            kol = 0;
            index = 0;
            string str = x.ToString();
            if (str[2].ToString() != str[3].ToString() && str[3].ToString() != str[4].ToString()&& str[2].ToString() + str[3].ToString() != str[4].ToString() + str[5].ToString())
            {
                string trs = str[2].ToString() + str[3].ToString() + str[4].ToString();
                for (int i = 5; i < str.Length - 2; i++)
                {
                    if (trs == str[i].ToString() + str[i + 1].ToString() + str[i + 2].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }
        public bool check4s(double x, out bool X, out int kol, out int index)
        {
            kol = 0;
            index = 0;
            string str = x.ToString();
            if (str[2].ToString() + str[3].ToString() != str[4].ToString() + str[5].ToString())
            {
                string fous = str[2].ToString() + str[3].ToString() + str[4].ToString() + str[5].ToString();
                for (int i = 6; i < str.Length - 3; i++)
                {
                    if (fous == str[i].ToString() + str[i + 1].ToString() + str[i + 2].ToString() + str[i + 3].ToString()) { kol++; if (kol == 1) index = i; };
                }
            }
            if (kol > 0) X = true;
            else X = false;
            return X;
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string M="", K="";
            int kol = 0, index=0;
            bool X = true;
            double D = 0;
            getm(textBox2.Text, out X);
            if(X==true)M = textBox2.Text;
            else MessageBox.Show("Введите число от 2 до 2000","Число M");
            X = false;
            int ss = Convert.ToInt32(M);
            getk(textBox1.Text, ss,out X);
            if(X==true){K =  textBox1.Text;
                 D = Convert.ToDouble(K) / Convert.ToDouble(M);
           
            if (check4s(D, out X, out kol, out index) == true)
            {
                string st = D.ToString();
                if (kol > 1)
                {
                    listBox1.Items.Add($"0,({st[2].ToString() + st[3].ToString() + st[4].ToString() + st[5].ToString()}) - Дробь не переодическая бесконечная");
                }
                else
                {
                    string stt = st[2].ToString() + st[3].ToString() + st[4].ToString() + st[5].ToString();
                        st = st.Remove(index);
                        st = st.Remove(0, 6);
                        listBox1.Items.Add($"0,{st}({stt}) - Дробь переодическая ");
                }
            }else
            if(check3s(D, out X, out kol, out index) == true)
            {
                string st = D.ToString();
                if (kol > 1)
                {
                    listBox1.Items.Add($"0,({st[2].ToString() + st[3].ToString() + st[4].ToString()}) - Дробь не переодическая бесконечная");
                }
                else
                {
                    string stt = st[2].ToString() + st[3].ToString() + st[4].ToString();
                        st = st.Remove(index);
                        st = st.Remove(0, 5);
                        listBox1.Items.Add($"0,{st}({stt}) - Дробь переодическая ");
                }
            }else
            if (check2s(D, out X, out kol, out index) == true)
                {
                    string st = D.ToString();
                    if (kol > 1)
                    {
                        listBox1.Items.Add($"0,({st[2].ToString() + st[3].ToString()}) - Дробь не переодическая бесконечная");
                    }
                    else
                    {
                        string stt = st[2].ToString() + st[3].ToString();
                        st=st.Remove(index);
                        st=st.Remove(0, 2);
                        listBox1.Items.Add($"0,{st}({stt}) - Дробь переодическая ");
                    }

                }else
                if (check1s(D, out X, out kol) == true)
                {
                    string st = D.ToString();
                    if (kol == st.Length - 3 || kol == st.Length - 4)
                    {
                        listBox1.Items.Add($"0,({st[2]}) - Дробь не переодическая бесконечная");
                    }
                    else if (kol == st.Length - 5)
                    {
                        string str = "0," + $"{st[2]}" + $"({st[3]}) - Дробь переодическая ";
                        listBox1.Items.Add(str);
                    }
                }
                else listBox1.Items.Add($"{D} - Дробь не переодическая ");
            }
            else MessageBox.Show("Введите число от 1 до M", "Число K");

        }
    }
}
