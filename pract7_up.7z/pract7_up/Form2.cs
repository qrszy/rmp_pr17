﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract7_up
{
    public partial class Form2 : Form
    {
        int index = 0, raz, index1 = 1;
        string player = "";
        List<string[]> ss = new List<string[]>();
        string[] mas = new string[4];
        public Form2()
        {
            InitializeComponent();
            if (File.Exists("t.txt"))
            {
                StreamReader fio = File.OpenText("t.txt");
                while (!fio.EndOfStream)
                {
                   for(int i =0; i < 4; i++) 
                    {
                        string str = fio.ReadLine();
                        mas[i] = str;
                    }
                   ss.Add(mas);
                }
                
                fio.Close();
                for(int i = 0;i<ss.Count;i++) 
                {
                    dataGridView1.Rows.Add(ss[i][0], ss[i][1], ss[i][2], ss[i][3]);
                }
            }
           

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            index++;
            
            if (index == 1) 
            {
                if (textBox1.Text != "") 
                {
                    player = textBox1.Text;
                    label1.Text = "Выбрать размер поля";
                    button2.Visible = true;
                    comboBox1.Visible = true;
                    button1.Enabled = false;
                }
                else { MessageBox.Show("Введите имя", "Ошибка");index--;}
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            if (index1 == 2) 
            {
                dataGridView1.Visible = true;
                button3.Text = "Назад";
                index1--;
            }
            if (index1 == 1)
            {
                dataGridView1.Visible = false;
                button3.Text = "См.Результаты";
                index1++;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1) 
            {
                if (comboBox1.SelectedIndex == 0) raz = 2;
                else
                    if (comboBox1.SelectedIndex == 1) raz = 4;
                else
                    if(comboBox1.SelectedIndex==2)raz = 6;
                Form1 f1 = new Form1(raz, player);
                f1.ShowDialog();
            }

        }

    }
}
