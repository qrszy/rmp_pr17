﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract9._2
{
    public partial class Form9 : Form
    {
        public bool getm(string x,out bool X)
        {
            if (x == "") return X = false;
            X = true;
            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= 2000 && A > 1) X = true;
            else X = false;
            return X;
        }
        public bool getk(string x,int m,out bool X)
        {
            if (x == "") return X = false;
             X = true;

            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A < m && A > 0) X = true;
            else X = false;
            return X;
        }
        public string CheckPeriod(int K, int M)
        {
            int[] saveost = new int[M];
            string result = ""; //1
            int ost = K % M;
                              //2          //3
            while (saveost[ost] == 0 && ost != 0)
            {
                //4
                saveost[ost] = result.Length + 1;
                K = ost * 10;
                result += (K / M).ToString();
                ost = K % M;
            }
            //5
            if (ost != 0)
            {
                //6
                int periodStartIndex = saveost[ost] - 1;
                result = result.Insert(periodStartIndex, "(") + ")";
            }
            //7
            return result;
        }
        private string AllMetod(string M,string K)
        {
            //8
            string st;
            string str = CheckPeriod(Convert.ToInt32(K), Convert.ToInt32(M));
            //9                           //10 
            if (str.IndexOf('(') == -1) { st = $"0.{str} - Дробь обыкновенная"; }
            //11                           //12
            else if (str.Length >= 8) { st = $"0.{str} - Дробь непериодическая конечная"; }
            //13                             //14
            else if (str.IndexOf('(') != 0) st = $"0.{str} - Дробь периодическая с предшествующими цифрами";
                 //15
            else st = $"0.{str} - Дробь периодическая бесконечная";
                 //16
            return st;
        }

        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool X = true;
            string M = textBox2.Text,K=textBox1.Text;
            
            getm(M, out X);
            if (X == true)
            {
                getk(K, Convert.ToInt32(M), out X);
                if (X == true)
                {
                    /*string str = CheckPeriod(Convert.ToInt32(K), Convert.ToInt32(M));
                    if (str.IndexOf('(') == -1) { listBox1.Items.Add($"0.{str} - Дробь обыкновенная"); }
                    else if (str.Length >= 8) { listBox1.Items.Add($"0.{str} - Дробь непериодическая конечная"); }
                    else if (str.IndexOf('(') != 0) listBox1.Items.Add($"0.{str} - Дробь периодическая с предшествующими цифрами");
                    else listBox1.Items.Add($"0.{str} - Дробь периодическая бесконечная");*/
                    listBox1.Items.Add(AllMetod(M, K));
                }
                else MessageBox.Show("Введите число от 1 до M", "Число K");
            }
            else MessageBox.Show("Введите число от 2 до 2000", "Число M");
        }
    }
}
