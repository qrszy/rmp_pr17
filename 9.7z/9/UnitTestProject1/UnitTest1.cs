﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using pract9._2;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
         Form9 f = new Form9();
        [TestMethod]
        public void TestMethod1()
        {
            int m=1, k=3;
            string actual = f.CheckPeriod(m, k);
            Assert.AreEqual("(3)",actual);
        }
        [TestMethod]
        public void TestMethod2()
        {
            int m = 1, k = 4;
            string actual = f.CheckPeriod(m, k);
            Assert.AreEqual("25", actual);
            
        }
        [TestMethod]
        public void TestMethod3()
        {
            int m = 3, k = 28;
            string actual = f.CheckPeriod(m, k);
            Assert.AreEqual("10(714285)", actual);
        }
        [TestMethod]
        public void TestMethod4()
        {
            int m = 1, k = 29;
            string actual = f.CheckPeriod(m, k);
            Assert.AreEqual("(0344827586206896551724137931)", actual);
        }
        [TestMethod]
        public void TestMethod5()
        {
            string m = "asdds";
            bool x;
            bool actual = f.getm(m,out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod6()
        {
            string m = "-11";
            bool x;
            bool actual = f.getm(m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod7()
        {
            string m = "2222";
            bool x;
            bool actual = f.getm(m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod8()
        {
            string m = "1";
            bool x;
            bool actual = f.getm(m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod13()
        {
            string m = "39";
            bool x;
            bool actual = f.getm(m, out x);
            Assert.AreEqual(true, actual);
        }

        [TestMethod]
        public void TestMethod9()
        {
            string k = "dva";
            int m = 123;
            bool x;
            bool actual = f.getk(k,m,out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod10()
        {
            string k = "-111";
            int m = 2;
            bool x;
            bool actual = f.getk(k, m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod11()
        {
            string k = "2222";
            int m = 200;
            bool x;
            bool actual = f.getk(k, m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod12()
        {
            string k = "2";
            int m = 2;
            bool x;
            bool actual = f.getk(k, m, out x);
            Assert.AreEqual(false, actual);
        }
        [TestMethod]
        public void TestMethod14()
        {
            string k = "2";
            int m = 39;
            bool x;
            bool actual = f.getk(k, m, out x);
            Assert.AreEqual(true, actual);
        }



    }
}
