﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTaskClassLibrary
{
    public class Test
    {
        public string GetStr(string str)
        {
            return str;
        }
        public bool Bukvi(string x)
        {
            bool X = true;
            if (x != "")
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (!Char.IsLetter(x[i])) X = false;
                }
                return X;
            }
            else
            {
                X = false;
                return X;
            }
        }
       
        public bool Name(string x) 
        {
            bool X = true;
            if (x != "")
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if(!Char.IsLetter(x[i]) && x[i] != ' '&& !Char.IsNumber(x[i])) X = false;
                }
                return X;
            }
            else
            {
                X = false;
                return X;
            }
        }
        public bool God(string x) 
        { 
            if (x == "") return false;
            bool X=true;           
         
            for (int i = 0; i < x.Length; i++)
            {
                if(!Char.IsNumber(x[i]))return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= 2024 && A > 0) X = true;
            else X = false;
            return X;
        }
        public bool kol(string x) 
        {
            if (x == "") return false;
            bool X = true;
            
            for (int i = 0; i < x.Length; i++)
            {
                if(!Char.IsNumber(x[i]))return false;
            }
            int A = Convert.ToInt32(x);
            x = A.ToString();
            if (A <= 1000 && A >= 0) X = true;
            else X = false;
            return X;
        }


    }
}
