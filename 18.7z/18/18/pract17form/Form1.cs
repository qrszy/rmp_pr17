using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract17form
{


    public partial class Form1 : Form
    {
        List<string[]> knigi = new List<string[]>();
        List<string[]> ycheb = new List<string[]>();
        static bool Bukvi(string x, out bool X)
        {
            X = true;
            if (x != "")
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (!Char.IsLetter(x[i])) X = false;
                }
                return X;
            }
            else
            {
                X = false;
                return X;
            }
        }
        public bool Name(string x, out bool X)
        {
            X = true;
            if (x != "")
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (!Char.IsLetter(x[i]) && x[i] != ' ' && !Char.IsNumber(x[i])) X = false;
                }
                return X;
            }
            else
            {
                X = false;
                return X;
            }
        }
        public bool God(string x,out bool X)
        {
            X = true;
            int A = Convert.ToInt32(x);
            x = A.ToString();
            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            if (A <= 2024 && A > 0) X = true;
            return X;
        }
        public bool kol(string x, out bool X)
        {
            X = true;
            int A = Convert.ToInt32(x);
            x = A.ToString();
            for (int i = 0; i < x.Length; i++)
            {
                if (!Char.IsNumber(x[i])) return false;
            }
            if (A <= 1000 && A >= 0) X = true;
            return X;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                label5.Text = "���-��";
                label6.Text = "����������";
                textBox6.Visible = true;
                label6.Visible = true;
            }
            else if (comboBox1.SelectedIndex == 0)
            {
                label6.Visible = false;
                textBox6.Visible = false;
                label5.Text = "����";
            }

        }
        private void radioButton1_Enter(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            knigi.Clear();
            StreamReader sw = File.OpenText("k.txt");
            while (!sw.EndOfStream)
            {
                string[] mas = sw.ReadLine().Split(' ');
                knigi.Add(mas);
            }
            sw.Close();
            for (int i = 0; i < knigi.Count; i++)
            {
                dataGridView2.Rows.Add(knigi[i][0], knigi[i][1], knigi[i][2], knigi[i][3], knigi[i][4]);
            }
            dataGridView1.Visible = false;
            dataGridView2.Visible = true; 
        }
        private void radioButton2_Enter(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            ycheb.Clear();
            StreamReader s = File.OpenText("y.txt");
            while (!s.EndOfStream)
            {
                string[] mas = s.ReadLine().Split(' ');
                ycheb.Add(mas);
            }
            s.Close();
            for (int i = 0; i < ycheb.Count; i++)
            {
                dataGridView1.Rows.Add(ycheb[i][0], ycheb[i][1], ycheb[i][2], ycheb[i][3], ycheb[i][4], ycheb[i][5]);
            }
            dataGridView2.Visible = false;
            dataGridView1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                string nado = textBox1.Text;
                dataGridView1.Rows.Clear();
                for (int i = 0; i < knigi.Count; i++)
                {
                    if (knigi[i][0] == nado || knigi[i][1] == nado || knigi[i][2] == nado || knigi[i][3] == nado || knigi[i][4] == nado)
                    {
                        dataGridView1.Rows.Add(knigi[i][0], knigi[i][1], knigi[i][2], knigi[i][3], knigi[i][4]);
                    }
                }
            }
            else
                if (radioButton2.Checked)
            {
                string nado = textBox1.Text;
                dataGridView1.Rows.Clear();
                for (int i = 0; i < ycheb.Count; i++)
                {
                    if (ycheb[i][0] == nado || ycheb[i][1] == nado || ycheb[i][2] == nado || ycheb[i][3] == nado || ycheb[i][4] == nado || ycheb[i][5] == nado)
                    {
                        dataGridView1.Rows.Add(ycheb[i][0], ycheb[i][1], ycheb[i][2], ycheb[i][3], ycheb[i][4], ycheb[i][5]);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                bool X = false; int A = 0, god = 0;
                string name = "", avtor = "", kartinki = "", janr = "";
                Name(textBox1.Text, out X);
                if(X==true)name = textBox1.Text; 
                X = false;
                Bukvi(textBox2.Text, out X);
                if(X==true)avtor = textBox2.Text; 
                X = false;
                God(textBox3.Text,out X);
                if (X == true)god =Convert.ToInt32(textBox3.Text); 
                X = false;
                if(Bukvi(textBox4.Text, out X) == true)kartinki = textBox4.Text;
                X = false;;
                Bukvi(textBox5.Text, out X);
                if (X == true)janr = textBox5.Text;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && janr != "")
                {
                    StreamWriter o = File.AppendText("k.txt");
                    o.WriteLine(name + " " + avtor + " " + god + " " + kartinki + " " + janr);
                    o.Close();
                    MessageBox.Show("���������");
                }
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                bool X = false; int A = 0;
                string name = "", avtor = "", kartinki = "", discp = "";
                int god = -1, kolvo = -1;

                
                Name(textBox1.Text, out X);
                if (X == true)name = textBox1.Text;
                X = false;
                Bukvi(textBox2.Text, out X);
                if (X == true)avtor = textBox2.Text;
                X = false;
                God(textBox3.Text, out X);
                if (X == true) god = Convert.ToInt32(textBox3.Text);
                X = false;              
                Bukvi(textBox4.Text, out X);
                if (X == true) kartinki = textBox4.Text;
                X = false;
                kol(textBox5.Text, out X);
                if (X == true) kolvo = Convert.ToInt32(textBox5.Text);
                X = false;
                Bukvi(textBox6.Text, out X);
                if (X == true) discp = textBox6.Text;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && kolvo != 0 && discp != "")
                {
                    StreamWriter o = File.AppendText("y.txt");
                    o.WriteLine(name+" "+avtor + " " + god + " " + kolvo + " " + kartinki + " " + discp);
                    o.Close();
                    MessageBox.Show("���������");
                }
            }
        }
           
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = true;

        }
        private void dataGridView2_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = true;

        }
        private void dataGridView2_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = false;
        }
        private void dataGridView1_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                int index = dataGridView1.CurrentCell.RowIndex;
                bool X = false; int A = 0, god = 0;
                string str, name = "", avtor = "", kartinki = "", janr = "";
                str = dataGridView1.Rows[index].Cells[0].Value.ToString();
                Bukvi(str, out X);
                if (X) { name = str; }
                X = false;
                str = dataGridView1.Rows[index].Cells[1].Value.ToString();
                Bukvi(str, out X);
                if (X) { avtor = str; }
                X = false;
                try
                {
                    A = Convert.ToInt32(dataGridView1.Rows[index].Cells[2]);
                    str = A.ToString();
                    for (int i = 0; i < str.Length; i++)
                    {
                        if (!Char.IsNumber(str[i])) X = false;
                    }
                }
                catch { MessageBox.Show("������� �����", "������"); }
                if (X) { god = A; }
                X = false;
                str = dataGridView1.Rows[index].Cells[3].Value.ToString();
                Bukvi(str, out X);
                if (X) { kartinki = str; }
                X = false;
                str = dataGridView1.Rows[index].Cells[4].Value.ToString();
                Bukvi(str, out X);
                if (X) janr = str;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && janr != "")
                {
                    knigi[index][0] = name;
                    knigi[index][1] = avtor;
                    knigi[index][2] = god.ToString();
                    knigi[index][3] = kartinki;
                    knigi[index][4] = janr;
                }

            }
            else
                if (radioButton2.Checked)
            {
                int index = dataGridView2.CurrentCell.RowIndex;


            }

        }
        
    }
}