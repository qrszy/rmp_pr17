﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MathTaskClassLibrary;
using System;
using System.IO;

namespace MathTaskClass
{
    [TestClass]
    public class UnitTest1
    {
        
        [TestMethod]

        public void TestMethod1()
        {
            string str = "hah";
            Test n = new Test();
            bool s = n.Bukvi(str);
                Assert.AreEqual(true,s);
        }
        [TestMethod]
        public void TestMethod2()
        {
            string str = "ha1ch";
            Test n = new Test();
            bool s = n.Bukvi(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod3()
        {
            string str = "1hach";
            Test n = new Test();
            bool s = n.Bukvi(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod4()
        {
            string str = "hah1";
            Test n = new Test();
            bool s = n.Bukvi(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod5()
        {
            string str = "";
            Test n = new Test();
            bool s = n.Bukvi(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod6()
        {
            string str = "часть1";
            Test n = new Test();
            bool s = n.Name(str);
            Assert.AreEqual(true, s);
        }
        [TestMethod]
        public void TestMethod7()
        {
            string str = "часть 1";
            Test n = new Test();
            bool s = n.Name(str);
            Assert.AreEqual(true, s);
        }
        [TestMethod]
        public void TestMethod8()
        {
            string str = "77";
            Test n = new Test();
            bool s = n.God(str);
            Assert.AreEqual(true, s);
        }
        [TestMethod]
        public void TestMethod9()
        {
            string str = "asdad";
            Test n = new Test();
            bool s = n.God(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod10()
        {
            string str = "-1000";
            Test n = new Test();
            bool s = n.God(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod11()
        {
            string str = "2536";
            Test n = new Test();
            bool s = n.God(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod12()
        {
            string str = "1";
            Test n = new Test();
            bool s = n.kol(str);
            Assert.AreEqual(true, s);

        }
        [TestMethod]
        public void TestMethod13()
        {
            string str = "";
            Test n = new Test();
            bool s = n.Name(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod14()
        {
            string str = "1111";
            Test n = new Test();
            bool s = n.kol(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod15()
        {
            string str = "-1";
            Test n = new Test();
            bool s = n.kol(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod16()
        {
            string str = "";
            Test n = new Test();
            bool s = n.kol(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod17()
        {
            string str = "";
            Test n = new Test();
            bool s = n.God(str);
            Assert.AreEqual(false, s);
        }
        [TestMethod]
        public void TestMethod18()
        {
            string str = "asdad";
            Test n = new Test();
            bool s = n.kol(str);
            Assert.AreEqual(false, s);
        }



    }
}
