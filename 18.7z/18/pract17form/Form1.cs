using System.Windows.Forms;

namespace pract17form
{


    public partial class Form1 : Form
    {
        List<string[]> knigi = new List<string[]>();
        List<string[]> ycheb = new List<string[]>();
        static bool Bukvi(string x, out bool X)
        {
            X = true;
            if (x != "")
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (!Char.IsLetter(x[i])) X = false;
                }
                return X;
            }
            else
            {
                X = false;
                return X;
            }
        }
        public Form1()
        {
            InitializeComponent();
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                label5.Text = "���-��";
                label6.Text = "����������";
                textBox6.Visible = true;
                label6.Visible = true;
            }
            else if (comboBox1.SelectedIndex == 0)
            {
                label6.Visible = false;
                textBox6.Visible = false;
                label5.Text = "����";
            }

        }





        private void radioButton1_Enter(object sender, EventArgs e)
        {
            StreamReader sw = File.OpenText("k.txt");
            while (!sw.EndOfStream)
            {
                string[] mas = new string[5];
                for (int j = 0; j < 5; j++)
                {
                    string st = sw.ReadLine();
                    mas[j] = st;
                }
                knigi.Add(mas);
            }
            sw.Close();
            for (int i = 0; i < knigi.Count; i++)
            {
                dataGridView1.Rows.Add(knigi[i][0], knigi[i][1], knigi[i][2], knigi[i][3], knigi[i][4]);
            }
            dataGridView2.Visible = false;
            dataGridView1.Visible = true; 
        }

        private void radioButton2_Enter(object sender, EventArgs e)
        {
            StreamReader s = File.OpenText("y.txt");
            while (!s.EndOfStream)
            {
                string[] mas = new string[6];
                for (int p = 0; p < 6; p++)
                {
                    string st = s.ReadLine();
                    mas[p] = st;
                }
                ycheb.Add(mas);
            }
            s.Close();
            for (int i = 0; i < ycheb.Count; i++)
            {
                dataGridView2.Rows.Add(ycheb[i][0], ycheb[i][1], ycheb[i][2], ycheb[i][3], ycheb[i][4], ycheb[i][5]);
            }

            dataGridView1.Visible = false;
            dataGridView2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                string nado = textBox1.Text;
                dataGridView1.Rows.Clear();
                for (int i = 0; i < knigi.Count; i++)
                {
                    if (knigi[i][0] == nado || knigi[i][1] == nado || knigi[i][2] == nado || knigi[i][3] == nado || knigi[i][4] == nado)
                    {
                        dataGridView1.Rows.Add(knigi[i][0], knigi[i][1], knigi[i][2], knigi[i][3], knigi[i][4]);
                    }
                }
            }
            else
                if (radioButton2.Checked)
            {
                string nado = textBox1.Text;
                dataGridView1.Rows.Clear();
                for (int i = 0; i < ycheb.Count; i++)
                {
                    if (ycheb[i][0] == nado || ycheb[i][1] == nado || ycheb[i][2] == nado || ycheb[i][3] == nado || ycheb[i][4] == nado || ycheb[i][5] == nado)
                    {
                        dataGridView1.Rows.Add(ycheb[i][0], ycheb[i][1], ycheb[i][2], ycheb[i][3], ycheb[i][4], ycheb[i][5]);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                bool X = false; int A = 0, god = 0;
                string str, name = "", avtor = "", kartinki = "", janr = "";
                str = textBox1.Text;
                Bukvi(str, out X);
                if(X==true)name = str; 
                X = false;
                str = textBox2.Text;
                Bukvi(str, out X);
                if(X==true)avtor = str; 
                X = false;
                try
                {
                    A = Convert.ToInt32(textBox3.Text);
                    str = A.ToString();
                    X = true;
                    for (int i = 0; i < str.Length; i++)
                    {
                        if (!Char.IsNumber(str[i])) X = false;
                    }
                }
                catch { MessageBox.Show("������� �����", "������"); }
                if (X == true)god = A; 
                X = false;
                str = textBox4.Text; ;
                if(Bukvi(str, out X) == true)kartinki = str;
                X = false;
                str = textBox5.Text;
                Bukvi(str, out X);
                if (X == true)janr = str;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && janr != "")
                {
                    StreamWriter o = File.AppendText("k.txt");
                    o.WriteLine(name + " " + avtor + " " + god + " " + kartinki + " " + janr);
                    o.Close();
                    MessageBox.Show("���������");
                }
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                bool X = false; int A = 0;
                string str, name = "", avtor = "", kartinki = "", discp = "";
                int god = -1, kolvo = -1;
                do
                {
                    str = textBox1.Text;
                    Bukvi(str, out X);
                } while (X != true);
                name = str;
                X = false;
                do
                {
                    str = textBox1.Text;
                    Bukvi(str, out X);
                } while (X != true);
                avtor = str;
                X = false;
                do
                {
                    try
                    {

                        A = Convert.ToInt32(textBox3.Text);
                        str = A.ToString();
                        X = true;
                        for (int i = 0; i < str.Length; i++)
                        {
                            if (!Char.IsNumber(str[i])) X = false;
                        }
                    }
                    catch { MessageBox.Show("������� �����", "������"); }
                } while (X == true);
                god = A;
                X = false;
                do
                {
                    str = textBox1.Text;
                    Bukvi(str, out X);
                } while (X != true);
                kartinki = str;
                X = false;
                do
                {
                    try
                    {

                        A = Convert.ToInt32(textBox3.Text);
                        str = A.ToString();
                        X = true;
                        for (int i = 0; i < str.Length; i++)
                        {
                            if (!Char.IsNumber(str[i])) X = false;
                        }
                    }
                    catch { MessageBox.Show("������� �����", "������"); }
                } while (X == true);
                kolvo = A;
                X = false;
                do
                {
                    str = textBox1.Text;
                    Bukvi(str, out X);
                } while (X != true);
                discp = str;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && kolvo != 0 && discp != "")
                {
                    StreamWriter o = File.AppendText("y.txt");
                    o.WriteLine(name+" "+avtor + " " + god + " " + kartinki + " " + kolvo + " " + discp);
                    o.Close();
                    MessageBox.Show("���������");
                }
            }
        }
           
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = true;

        }
        private void dataGridView2_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = true;

        }
        private void dataGridView2_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = false;
        }
        private void dataGridView1_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                int index = dataGridView1.CurrentCell.RowIndex;
                bool X = false; int A = 0, god = 0;
                string str, name = "", avtor = "", kartinki = "", janr = "";
                str = dataGridView1.Rows[index].Cells[0].Value.ToString();
                Bukvi(str, out X);
                if (X) { name = str; }
                X = false;
                str = dataGridView1.Rows[index].Cells[1].Value.ToString();
                Bukvi(str, out X);
                if (X) { avtor = str; }
                X = false;
                try
                {
                    A = Convert.ToInt32(dataGridView1.Rows[index].Cells[2]);
                    str = A.ToString();
                    for (int i = 0; i < str.Length; i++)
                    {
                        if (!Char.IsNumber(str[i])) X = false;
                    }
                }
                catch { MessageBox.Show("������� �����", "������"); }
                if (X) { god = A; }
                X = false;
                str = dataGridView1.Rows[index].Cells[3].Value.ToString();
                Bukvi(str, out X);
                if (X) { kartinki = str; }
                X = false;
                str = dataGridView1.Rows[index].Cells[4].Value.ToString();
                Bukvi(str, out X);
                if (X) janr = str;
                X = false;
                if (name != "" && avtor != "" && god != 0 && kartinki != "" && janr != "")
                {
                    knigi[index][0] = name;
                    knigi[index][1] = avtor;
                    knigi[index][2] = god.ToString();
                    knigi[index][3] = kartinki;
                    knigi[index][4] = janr;
                }

            }
            else
                if (radioButton2.Checked)
            {
                int index = dataGridView2.CurrentCell.RowIndex;


            }

        }
        
    }
}